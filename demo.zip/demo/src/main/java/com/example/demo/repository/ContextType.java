package com.example.demo.repository;

public enum ContextType {

    ORDER_CONTEXT
    //, SERVICE_CONTEXT
}