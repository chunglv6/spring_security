package com.example.demo.repository;
public enum Direction {
    INBOUND,
    OUTBOUND, INTERNAL
}
