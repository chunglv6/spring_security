package com.example.demo.controller;

import com.example.demo.repository.Context;
import com.example.demo.repository.ContextRepository;
import com.example.demo.repository.ContextType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.bson.Document;

import java.util.Arrays;
import java.util.List;

@RestController
public class TestController {
    @Autowired
    private ContextRepository contextRepository;

    @GetMapping("/user")
    public List<Context> getUser(){
        List<Document> pipeline =  Arrays.asList(new Document("$search",
                new Document("index", "default")
                        .append("compound",
                                new Document("must", Arrays.asList(new Document("text",
                                                new Document("path", "header.outletId")
                                                        .append("query", "GS0001223")),
                                        new Document("text",
                                                new Document("path", "type")
                                                        .append("query", "ORDER_CONTEXT")),
                                        new Document("regex",
                                                new Document("path", Arrays.asList("display.customerLastName", "display.customerFirstName", "display.licensePlateNumber", "display.finOrVin", "contextMetaData.status", "header.orderId"))
                                                        .append("query", "WDD(.*)")
                                                        .append("allowAnalyzedField", true)))))));
        System.out.println(pipeline.toArray());
        List<Context> response = contextRepository.findByHeaderOutletIdAndType(pipeline.toString());
        return response;
    }
}
