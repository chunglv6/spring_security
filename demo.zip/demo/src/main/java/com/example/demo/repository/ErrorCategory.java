package com.example.demo.repository;

public enum ErrorCategory {
    BUSINESS,
    TECHNICAL
}
