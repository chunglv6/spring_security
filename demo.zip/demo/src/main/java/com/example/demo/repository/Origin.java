package com.example.demo.repository;
public enum Origin {
    DMS,
    OCS,
    XJ_SERVICE,
    PJ_SERVICE,
    SRS_DS
}