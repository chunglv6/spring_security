package com.example.demo.repository;

public enum Operation {
    INIT_JOB,
    FINISH_ORDER,
    TRANSFER_TO_DMS
}
