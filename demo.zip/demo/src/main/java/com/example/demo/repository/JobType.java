package com.example.demo.repository;


public enum JobType {
    TECHNICAL_JOB, PARTS_JOB
}
