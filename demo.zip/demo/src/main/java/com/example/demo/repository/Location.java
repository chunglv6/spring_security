package com.example.demo.repository;

public enum Location {
    XP_API,
    RETAIL_ADAPTER,
    XJS_ADAPTER,
    PJS_ADAPTER
}