package com.example.demo.repository;

public enum Severity {
    ERROR,WARNING,ERROR_WITHOUT_XSF
}
