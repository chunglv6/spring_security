package com.eazybytes.springsecuritybasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringsecuritybasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
